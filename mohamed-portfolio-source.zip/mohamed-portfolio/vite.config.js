import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

/**
 * `npm run build`        -> regular multi-file production build in /dist
 * `npm run build:single` -> one self-contained HTML file (handy for quick previews / email)
 *
 * `base: './'` keeps asset URLs relative so the build works on Netlify, Vercel,
 * GitHub Pages (project sites) or any static host without extra configuration.
 */
export default defineConfig(({ mode }) => ({
  base: './',
  plugins: [react(), ...(mode === 'single' ? [viteSingleFile()] : [])],
  css: {
    preprocessorOptions: {
      scss: {
        // Bootstrap 5.3 still uses @import / legacy Sass helpers; keep the console clean.
        quietDeps: true,
        silenceDeprecations: ['import', 'global-builtin', 'color-functions', 'if-function'],
      },
    },
  },
}));
