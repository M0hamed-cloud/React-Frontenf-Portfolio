# Mohamed Ahmed — Front-End Portfolio

A dark, editorial, developer-centric portfolio built with **React**, **Bootstrap 5 (themed through Sass)** and modern CSS3.

## Quick start

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production build in /dist
npm run preview    # serve the production build locally
```

Optional: `npm run build:single` produces `dist-single/index.html`, one self-contained file that is handy for quick previews.

## Where to edit things

| I want to change…                         | Edit                                  |
| ----------------------------------------- | ------------------------------------- |
| Any text, skills, projects, links, dates  | `src/data/profile.js`                 |
| My photo                                  | replace `src/assets/mohamed.jpg`      |
| My CV download                            | replace `public/Mohamed_Ahmed_FrontEnd_CV.pdf` (keep the file name) |
| Colours, fonts, spacing tokens            | `:root` in `src/styles/_base.scss` and the variables at the top of `src/styles/_bootstrap-custom.scss` |

### Add your GitHub / LinkedIn / project links

Links are optional and only render when they have a value, so there are never dead buttons:

```js
// src/data/profile.js
socials: { github: 'https://github.com/your-handle', linkedin: 'https://www.linkedin.com/in/your-handle' },

// inside a project
links: { repo: 'https://github.com/your-handle/your-repo', demo: 'https://your-demo.example' },
```

## Structure

```
src/
├── App.jsx                     page shell, scroll-spy wiring
├── main.jsx
├── data/profile.js             ALL content (single source of truth)
├── hooks/                      useInView, useScrollSpy, usePrefersReducedMotion
├── utils/dates.js              monthsSince() for the live DEPI badge
├── components/
│   ├── SiteNav.jsx             react-bootstrap Navbar, blur-on-scroll, active link
│   ├── Hero/                   Hero + HeroPortrait (tilt, code chip)
│   ├── About/  Training/  Skills/  Projects/  Contact/
│   ├── Footer.jsx
│   └── ui/                     Reveal, SectionHeading, Icon, CursorGlow, ScrollProgress, RotatingWord
└── styles/
    ├── _bootstrap-custom.scss  Bootstrap themed via Sass variables, only needed partials imported
    ├── _base.scss              tokens, primitives, keyframes, reduced-motion rules
    ├── _layout.scss            nav, hero, section frame, footer
    └── _sections.scss          About, Training, Skills, Projects, Contact
```

## Design & engineering notes

- **Bootstrap, not stock Bootstrap**: grid, forms, buttons and navbar come from Bootstrap, but colours, type, radii and form controls are themed at the Sass level.
- **Accessibility**: semantic landmarks, skip link, visible focus states, an ARIA tabs pattern with arrow/Home/End keys for the skill explorer, labelled form with inline validation, and `prefers-reduced-motion` support (reveals, ticker, tilt, cursor glow and rotating words all switch off).
- **Performance**: only the Bootstrap partials in use are compiled, no icon fonts (inline SVG), images sized with width/height, and animations use `transform`/`opacity`.
- **Contact form** needs no backend: it opens the visitor's email app with a pre-filled message to your address.
- Fonts (Geist, Instrument Serif, JetBrains Mono) load from Google Fonts in `index.html`.

## Deploying

`base: './'` is set in `vite.config.js`, so the contents of `dist/` work on Netlify, Vercel, Cloudflare Pages or GitHub Pages (project sites) without extra configuration.
