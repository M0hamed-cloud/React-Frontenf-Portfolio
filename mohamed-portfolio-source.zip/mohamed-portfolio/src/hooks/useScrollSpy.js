import { useEffect, useState } from 'react';

/**
 * Tracks which section is currently crossing the middle band of the viewport.
 * @param {string[]} ids element ids in page order
 * @returns {string} the id of the active section
 */
export function useScrollSpy(ids) {
  const [active, setActive] = useState(ids[0]);
  const key = ids.join('|');

  useEffect(() => {
    if (!('IntersectionObserver' in window)) return undefined;

    const elements = key
      .split('|')
      .map((id) => document.getElementById(id))
      .filter(Boolean);

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id);
        });
      },
      // A thin band around 40–45% of the viewport height decides the active section.
      { rootMargin: '-40% 0px -55% 0px' },
    );

    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [key]);

  return active;
}
