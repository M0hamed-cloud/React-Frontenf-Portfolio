/**
 * Whole calendar months elapsed between an ISO date string and `now`.
 * Used by the DEPI card so the "months in" badge stays accurate without manual edits.
 */
export function monthsSince(startISO, now = new Date()) {
  const start = new Date(startISO);
  let months = (now.getFullYear() - start.getFullYear()) * 12 + (now.getMonth() - start.getMonth());
  if (now.getDate() < start.getDate()) months -= 1;
  return Math.max(months, 0);
}
