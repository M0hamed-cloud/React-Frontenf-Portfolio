import { Col, Container, Row } from 'react-bootstrap';
import { training } from '../../data/profile';
import { monthsSince } from '../../utils/dates';
import Reveal from '../ui/Reveal';
import SectionHeading from '../ui/SectionHeading';

/**
 * Professional training & initiatives — DEPI.
 * Left: sticky programme card with a live "months in" badge. Right: the four learning tracks.
 */
export default function Training() {
  const months = monthsSince(training.start);

  return (
    <section id="training" className="section section--raised" aria-labelledby="training-title">
      <Container>
        <SectionHeading
          id="training-title"
          index="02"
          label="Professional training"
          title={
            <>
              Hands-on with <em>DEPI</em>, on the clock.
            </>
          }
          lead="An intensive, government-backed programme that turns fundamentals into professional engineering habits."
        />

        <Row className="gy-5 gx-xl-5">
          <Col lg={5}>
            <Reveal className="program">
              <div className="program__top">
                <span className="badge-live">
                  <span className="status-dot" aria-hidden="true" /> Ongoing
                </span>
                <span className="program__months">
                  {months > 0 ? `${months} month${months === 1 ? '' : 's'} in` : 'Just started'}
                </span>
              </div>

              <h3 className="program__org">{training.organisation}</h3>
              <p className="program__parent">{training.parent}</p>

              <dl className="program__rows">
                <div>
                  <dt>Role</dt>
                  <dd>{training.role}</dd>
                </div>
                <div>
                  <dt>Period</dt>
                  <dd>
                    {training.startLabel} – {training.endLabel}
                  </dd>
                </div>
                <div>
                  <dt>Track</dt>
                  <dd>Front-End Web Development</dd>
                </div>
              </dl>
            </Reveal>
          </Col>

          <Col lg={7}>
            <ol className="timeline">
              {training.tracks.map((track, i) => (
                <Reveal as="li" key={track.title} delay={i * 70} className="timeline__item">
                  <span className="timeline__node" aria-hidden="true">
                    {i + 1}
                  </span>
                  <h3 className="timeline__title">{track.title}</h3>
                  <p>{track.text}</p>
                  <ul className="tag-row" aria-label={`${track.title} topics`}>
                    {track.tags.map((tag) => (
                      <li key={tag} className="tag">
                        {tag}
                      </li>
                    ))}
                  </ul>
                </Reveal>
              ))}
            </ol>
          </Col>
        </Row>
      </Container>
    </section>
  );
}
