import { Container } from 'react-bootstrap';
import { projects } from '../../data/profile';
import SectionHeading from '../ui/SectionHeading';
import ProjectCard from './ProjectCard';

export default function Projects() {
  return (
    <section id="projects" className="section section--raised" aria-labelledby="projects-title">
      <Container>
        <SectionHeading
          id="projects-title"
          index="04"
          label="Featured projects"
          title={
            <>
              Selected work, <em>built to be reused.</em>
            </>
          }
          lead="Interfaces designed around reusable components, clean state and layouts that hold up on any device."
        />

        <div className="projects">
          {projects.map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      </Container>
    </section>
  );
}
