import { profile } from '../../data/profile';
import Icon from '../ui/Icon';
import Reveal from '../ui/Reveal';

/**
 * One featured project, laid out like an editorial index row.
 * Optional links only render when they have a URL — there are never dead buttons.
 * Every project also gets a pre-filled "Discuss" email link.
 */
export default function ProjectCard({ project }) {
  const { index, kind, title, summary, highlights, tags, swatches, links } = project;
  const subject = encodeURIComponent(`About your project: ${title}`);
  const mailto = `mailto:${profile.email}?subject=${subject}`;

  return (
    <Reveal as="article" className="project" aria-labelledby={`project-${project.id}`}>
      <div className="project__head">
        <span className="project__index">{index}</span>
        <span className="project__kind">{kind}</span>
      </div>

      <div className="project__body">
        <div className="project__main">
          <h3 id={`project-${project.id}`} className="project__title">
            {title}
          </h3>
          <p className="project__summary">{summary}</p>

          <ul className="tag-row" aria-label="Technologies used">
            {tags.map((tag) => (
              <li key={tag} className="tag">
                {tag}
              </li>
            ))}
          </ul>

          {swatches && (
            <ul className="swatches" aria-label="Design tokens used on this site">
              {swatches.map((s) => (
                <li key={s.name}>
                  <span className="swatches__chip" style={{ background: s.value }} aria-hidden="true" />
                  <span className="swatches__name">{s.name}</span>
                  <code>{s.value}</code>
                </li>
              ))}
            </ul>
          )}
        </div>

        <dl className="project__highlights">
          {highlights.map((h) => (
            <div key={h.label}>
              <dt>{h.label}</dt>
              <dd>{h.text}</dd>
            </div>
          ))}
        </dl>
      </div>

      <div className="project__actions">
        {links.repo && (
          <a className="btn btn-sm btn-ghost btn-arrow" href={links.repo} target="_blank" rel="noreferrer">
            <Icon name="github" size={16} /> Source
          </a>
        )}
        {links.demo && (
          <a className="btn btn-sm btn-primary btn-arrow" href={links.demo} target="_blank" rel="noreferrer">
            Live demo <Icon name="arrow-up-right" size={16} />
          </a>
        )}
        <a className="link-quiet" href={mailto}>
          Discuss this project <Icon name="arrow-up-right" size={16} />
        </a>
      </div>
    </Reveal>
  );
}
