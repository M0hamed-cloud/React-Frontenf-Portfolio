import { Col, Container, Row } from 'react-bootstrap';
import { education, principles, profile } from '../../data/profile';
import Reveal from '../ui/Reveal';
import SectionHeading from '../ui/SectionHeading';

/** Segmented "year 3 of 4" track. Purely visual; the text label carries the meaning. */
function YearTrack({ current, total }) {
  return (
    <div className="year-track" role="img" aria-label={`Year ${current} of ${total}`}>
      {Array.from({ length: total }, (_, i) => {
        const year = i + 1;
        const state = year < current ? 'done' : year === current ? 'current' : 'todo';
        return (
          <span key={year} className={`year-track__seg is-${state}`}>
            <span className="year-track__label">Y{year}</span>
          </span>
        );
      })}
    </div>
  );
}

export default function About() {
  return (
    <section id="about" className="section" aria-labelledby="about-title">
      <Container>
        <SectionHeading
          id="about-title"
          index="01"
          label="About"
          title={
            <>
              A student of computer science, <em>a maker</em> of interfaces.
            </>
          }
        />

        <Row className="gy-5 gx-xl-5">
          <Col lg={7}>
            <Reveal>
              <p className="lead-text">
                I’m a motivated third-year Computer Science student at {education.institution} in Maadi, Cairo — and a
                front-end developer who loves the part of software people actually touch.
              </p>
            </Reveal>
            <Reveal delay={80}>
              <p>
                My journey started with the fundamentals — semantic HTML5, CSS3 and modern JavaScript (ES6+) — and grew
                into component-based development with React and TypeScript. Today I’m deepening that foundation through
                the Digital Egypt Pioneers Initiative, where I’m learning to build accessible, high-performance
                client-side applications the way professional teams do.
              </p>
            </Reveal>
            <Reveal delay={140}>
              <p>
                I care about clean-code standards, UI/UX principles and modern web application development — and I use
                Git and GitHub to keep every project organized and collaborative. Exposure to Node.js, Express and
                Docker basics means I can talk to the rest of the stack, too.
              </p>
            </Reveal>

            <ol className="principles">
              {principles.map((item, i) => (
                <Reveal as="li" key={item.title} delay={i * 80} className="principles__item">
                  <span className="principles__num">{String(i + 1).padStart(2, '0')}</span>
                  <div>
                    <h3 className="principles__title">{item.title}</h3>
                    <p>{item.text}</p>
                  </div>
                </Reveal>
              ))}
            </ol>
          </Col>

          <Col lg={5}>
            <Reveal delay={100} as="aside" className="ledger" aria-label="Education">
              <p className="ledger__kicker">Education</p>
              <h3 className="ledger__title">{education.degree}</h3>
              <p className="ledger__school">
                {education.institution} <span>· {education.place}</span>
              </p>

              <YearTrack current={education.currentYear} total={education.totalYears} />

              <dl className="ledger__rows">
                <div>
                  <dt>Status</dt>
                  <dd>Year {education.currentYear} · in progress</dd>
                </div>
                <div>
                  <dt>Expected graduation</dt>
                  <dd>{education.expectedGraduation}</dd>
                </div>
                <div>
                  <dt>Focus</dt>
                  <dd>Front-end web development</dd>
                </div>
                <div>
                  <dt>Location</dt>
                  <dd>{profile.location}</dd>
                </div>
              </dl>
            </Reveal>
          </Col>
        </Row>
      </Container>
    </section>
  );
}
