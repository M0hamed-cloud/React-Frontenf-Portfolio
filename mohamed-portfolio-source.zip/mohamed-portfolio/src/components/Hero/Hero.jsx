import { Col, Container, Row } from 'react-bootstrap';
import { education, profile } from '../../data/profile';
import Icon from '../ui/Icon';
import Reveal from '../ui/Reveal';
import RotatingWord from '../ui/RotatingWord';
import HeroPortrait from './HeroPortrait';

/**
 * First screen. Photo leads on mobile (so a face greets the visitor), sits on the right on desktop.
 */
export default function Hero() {
  return (
    <section id="home" className="hero" aria-labelledby="hero-title">
      <div className="hero__grid" aria-hidden="true" />
      <div className="hero__orb" aria-hidden="true" />

      <Container className="hero__container">
        <Row className="align-items-center gy-5 gx-xl-5">
          <Col lg={5} className="order-lg-2">
            <HeroPortrait />
          </Col>

          <Col lg={7} className="order-lg-1">
            <Reveal>
              <p className="eyebrow">
                <span className="status-dot" aria-hidden="true" />
                Computer Science student · {profile.role}
              </p>
            </Reveal>

            <Reveal delay={80}>
              <h1 id="hero-title" className="hero__title">
                Clean code,
                <br />
                <em>considered</em> interfaces.
              </h1>
            </Reveal>

            <Reveal delay={160}>
              <p className="hero__lead">
                I’m <strong>{profile.name}</strong> — a third-year student at {education.institution} building
                responsive, accessible web interfaces with React, currently training in the Digital Egypt Pioneers
                Initiative.
              </p>
            </Reveal>

            <Reveal delay={220}>
              <p className="hero__now">
                <span className="hero__now-label">Currently sharpening</span>
                <RotatingWord words={profile.focusWords} />
              </p>
            </Reveal>

            <Reveal delay={280}>
              <div className="hero__actions">
                <a className="btn btn-primary btn-arrow" href="#projects">
                  View projects <Icon name="arrow-right" />
                </a>
                <a className="btn btn-ghost btn-arrow" href="#contact">
                  Get in touch <Icon name="arrow-up-right" />
                </a>
                <a className="link-quiet" href={profile.cvUrl} download>
                  <Icon name="download" size={16} /> Download CV
                </a>
              </div>
            </Reveal>

            <Reveal delay={340}>
              <dl className="hero__meta">
                <div>
                  <dt>Based in</dt>
                  <dd>{profile.location}</dd>
                </div>
                <div>
                  <dt>Studying</dt>
                  <dd>
                    {education.institution}, class of {education.expectedGraduation.split(' ')[1]}
                  </dd>
                </div>
                <div>
                  <dt>Stack</dt>
                  <dd>React · TypeScript · Bootstrap</dd>
                </div>
              </dl>
            </Reveal>
          </Col>
        </Row>
      </Container>

      <a className="hero__scroll" href="#about" aria-label="Scroll to About">
        <span>Scroll</span>
        <span className="hero__scroll-line" aria-hidden="true" />
      </a>
    </section>
  );
}
