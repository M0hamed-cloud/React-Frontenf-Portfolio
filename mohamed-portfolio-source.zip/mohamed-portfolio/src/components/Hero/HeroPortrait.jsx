import { useRef } from 'react';
import portrait from '../../assets/mohamed.jpg';
import { profile } from '../../data/profile';
import { usePrefersReducedMotion } from '../../hooks/usePrefersReducedMotion';
import Reveal from '../ui/Reveal';

/** Lines of the floating "code chip". Pure presentation, mirrors real CV data. */
const CODE = [
  [['k', 'const'], ['v', ' mohamed'], ['p', ' = {']],
  [['p', '  role: '], ['s', "'Front-End Developer'"], ['p', ',']],
  [['p', '  stack: ['], ['s', "'React'"], ['p', ', '], ['s', "'TypeScript'"], ['p', '],']],
  [['p', '  training: '], ['s', "'DEPI 2026'"], ['p', ',']],
  [['p', '};']],
];

/**
 * Hero portrait: framed photo with corner marks, a gentle pointer-driven tilt,
 * a status pill and a floating code chip. Tilt is skipped for reduced-motion users.
 */
export default function HeroPortrait() {
  const figureRef = useRef(null);
  const reduced = usePrefersReducedMotion();

  const handleMove = (event) => {
    if (reduced || event.pointerType === 'touch') return;
    const el = figureRef.current;
    const rect = el.getBoundingClientRect();
    const px = (event.clientX - rect.left) / rect.width - 0.5;
    const py = (event.clientY - rect.top) / rect.height - 0.5;
    el.style.setProperty('--rx', `${(-py * 6).toFixed(2)}deg`);
    el.style.setProperty('--ry', `${(px * 8).toFixed(2)}deg`);
  };

  const handleLeave = () => {
    const el = figureRef.current;
    el.style.setProperty('--rx', '0deg');
    el.style.setProperty('--ry', '0deg');
  };

  return (
    <Reveal delay={120} className="portrait-wrap">
      <figure ref={figureRef} className="portrait" onPointerMove={handleMove} onPointerLeave={handleLeave}>
        <div className="portrait__frame">
          <img
            src={portrait}
            width="977"
            height="977"
            alt={`Portrait of ${profile.name} sitting at his desk, wearing clear-framed glasses and a black sweater`}
            decoding="async"
            fetchPriority="high"
          />
          <span className="portrait__shade" aria-hidden="true" />
          <span className="corner corner--tl" aria-hidden="true" />
          <span className="corner corner--tr" aria-hidden="true" />
          <span className="corner corner--bl" aria-hidden="true" />
          <span className="corner corner--br" aria-hidden="true" />

          <span className="portrait__pill">
            <span className="status-dot" aria-hidden="true" />
            DEPI · 2026
          </span>
        </div>

        <figcaption className="portrait__caption">
          <span>Fig. 01</span>
          <span>{profile.name}</span>
          <span>Qalyubia · EG</span>
        </figcaption>

        <div className="code-chip" aria-hidden="true">
          {CODE.map((line, i) => (
            <div key={i} className="code-chip__line">
              {line.map(([type, text], j) => (
                <span key={j} className={`tok-${type}`}>
                  {text}
                </span>
              ))}
            </div>
          ))}
        </div>
      </figure>
    </Reveal>
  );
}
