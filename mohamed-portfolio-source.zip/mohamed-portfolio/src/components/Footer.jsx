import { Container } from 'react-bootstrap';
import { profile } from '../data/profile';
import Icon from './ui/Icon';

export default function Footer() {
  return (
    <footer className="site-footer">
      <Container className="site-footer__inner">
        <p>
          © {new Date().getFullYear()} {profile.name}
        </p>
        <p className="site-footer__built">Designed &amp; built with React, Bootstrap and Sass.</p>
        <a href="#home" className="link-quiet">
          Back to top <Icon name="arrow-up" size={15} />
        </a>
      </Container>
    </footer>
  );
}
