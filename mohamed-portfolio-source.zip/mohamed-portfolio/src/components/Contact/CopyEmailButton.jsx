import { useEffect, useState } from 'react';
import Icon from '../ui/Icon';

/**
 * Copies a value to the clipboard and confirms it inline.
 * Falls back to a hidden textarea where the async Clipboard API is unavailable.
 */
export default function CopyButton({ value, label = 'Copy' }) {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!copied) return undefined;
    const id = setTimeout(() => setCopied(false), 2000);
    return () => clearTimeout(id);
  }, [copied]);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
    } catch {
      const area = document.createElement('textarea');
      area.value = value;
      area.setAttribute('readonly', '');
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      document.execCommand('copy');
      document.body.removeChild(area);
    }
    setCopied(true);
  };

  return (
    <button type="button" className={`copy-btn${copied ? ' is-copied' : ''}`} onClick={copy}>
      <Icon name={copied ? 'check' : 'copy'} size={15} />
      <span>{copied ? 'Copied' : label}</span>
      {/* Announce the result to screen readers without moving focus */}
      <span className="visually-hidden" role="status" aria-live="polite">
        {copied ? `${value} copied to clipboard` : ''}
      </span>
    </button>
  );
}
