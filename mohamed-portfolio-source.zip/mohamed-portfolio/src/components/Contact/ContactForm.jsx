import { useState } from 'react';
import { Form } from 'react-bootstrap';
import { profile } from '../../data/profile';
import Icon from '../ui/Icon';

/**
 * No backend needed: on a valid submit we open the visitor's email app with a
 * pre-filled message addressed to Mohamed (mailto:). Validation uses Bootstrap's
 * constraint-validation styling, restyled in _sections.scss.
 */
export default function ContactForm() {
  const [values, setValues] = useState({ name: '', message: '' });
  const [validated, setValidated] = useState(false);
  const [opened, setOpened] = useState(false);

  const onChange = (event) => {
    const { name, value } = event.target;
    setValues((prev) => ({ ...prev, [name]: value }));
  };

  const onSubmit = (event) => {
    event.preventDefault();
    if (!event.currentTarget.checkValidity()) {
      setValidated(true);
      return;
    }
    const subject = encodeURIComponent(`Portfolio enquiry from ${values.name.trim()}`);
    const body = encodeURIComponent(`Hi ${profile.firstName},\n\n${values.message.trim()}\n\n— ${values.name.trim()}`);
    window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`;
    setOpened(true);
  };

  return (
    <Form noValidate validated={validated} onSubmit={onSubmit} className="contact-form" aria-label="Send a message">
      <Form.Group controlId="contact-name" className="contact-form__group">
        <Form.Label>Your name</Form.Label>
        <Form.Control
          name="name"
          type="text"
          autoComplete="name"
          placeholder="Ada Lovelace"
          required
          minLength={2}
          value={values.name}
          onChange={onChange}
        />
        <Form.Control.Feedback type="invalid">Please tell me who you are.</Form.Control.Feedback>
      </Form.Group>

      <Form.Group controlId="contact-message" className="contact-form__group">
        <Form.Label>Message</Form.Label>
        <Form.Control
          name="message"
          as="textarea"
          rows={5}
          placeholder="Tell me about the role, project or idea…"
          required
          minLength={10}
          value={values.message}
          onChange={onChange}
        />
        <Form.Control.Feedback type="invalid">A few words please (10 characters or more).</Form.Control.Feedback>
      </Form.Group>

      <div className="contact-form__footer">
        <button type="submit" className="btn btn-primary btn-arrow">
          Compose email <Icon name="send" />
        </button>
        <p className="contact-form__hint" role="status" aria-live="polite">
          {opened ? 'Your email app should have opened — just hit send.' : 'Opens your email app with the message ready to send.'}
        </p>
      </div>
    </Form>
  );
}
