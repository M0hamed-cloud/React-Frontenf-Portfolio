import { Col, Container, Row } from 'react-bootstrap';
import { profile } from '../../data/profile';
import Icon from '../ui/Icon';
import Reveal from '../ui/Reveal';
import SectionHeading from '../ui/SectionHeading';
import ContactForm from './ContactForm';
import CopyButton from './CopyEmailButton';

/** Real, working connection points taken from the CV (plus optional socials when set). */
export default function Contact() {
  const { socials } = profile;

  const rows = [
    {
      icon: 'mail',
      label: 'Email',
      value: profile.email,
      href: `mailto:${profile.email}`,
      action: <CopyButton value={profile.email} label="Copy" />,
    },
    {
      icon: 'phone',
      label: 'Phone',
      value: profile.phoneDisplay,
      href: `tel:${profile.phone}`,
    },
    {
      icon: 'chat',
      label: 'WhatsApp',
      value: 'Message me directly',
      href: profile.whatsapp,
      external: true,
    },
    {
      icon: 'pin',
      label: 'Location',
      value: profile.location,
    },
  ];

  return (
    <section id="contact" className="section section--contact" aria-labelledby="contact-title">
      <Container>
        <SectionHeading
          id="contact-title"
          index="05"
          label="Contact"
          title={
            <>
              Let’s build something <em>worth shipping.</em>
            </>
          }
          lead="I’m looking for chances to learn, contribute and grow as a front-end developer. If you’re hiring, mentoring or collaborating, I’d love to hear from you."
        />

        <Row className="gy-5 gx-xl-5">
          <Col lg={6}>
            <ul className="contact-list">
              {rows.map((row, i) => (
                <Reveal as="li" key={row.label} delay={i * 60} className="contact-list__row">
                  <span className="contact-list__icon">
                    <Icon name={row.icon} size={18} />
                  </span>
                  <div className="contact-list__text">
                    <span className="contact-list__label">{row.label}</span>
                    {row.href ? (
                      <a
                        href={row.href}
                        className="contact-list__value"
                        {...(row.external ? { target: '_blank', rel: 'noreferrer' } : {})}
                      >
                        {row.value}
                      </a>
                    ) : (
                      <span className="contact-list__value">{row.value}</span>
                    )}
                  </div>
                  {row.action}
                </Reveal>
              ))}
            </ul>

            {(socials.github || socials.linkedin) && (
              <Reveal delay={260} className="socials">
                {socials.github && (
                  <a className="btn btn-sm btn-ghost btn-arrow" href={socials.github} target="_blank" rel="noreferrer">
                    <Icon name="github" size={16} /> GitHub
                  </a>
                )}
                {socials.linkedin && (
                  <a className="btn btn-sm btn-ghost btn-arrow" href={socials.linkedin} target="_blank" rel="noreferrer">
                    <Icon name="linkedin" size={16} /> LinkedIn
                  </a>
                )}
              </Reveal>
            )}
          </Col>

          <Col lg={6}>
            <Reveal delay={120} className="contact-card">
              <ContactForm />
            </Reveal>
          </Col>
        </Row>
      </Container>
    </section>
  );
}
