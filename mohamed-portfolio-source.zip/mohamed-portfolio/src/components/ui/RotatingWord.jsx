import { useEffect, useState } from 'react';
import { usePrefersReducedMotion } from '../../hooks/usePrefersReducedMotion';

/**
 * Cycles through `words`. The animated text is hidden from assistive tech and replaced
 * by a single static list, so screen-reader users aren't interrupted every few seconds.
 */
export default function RotatingWord({ words, interval = 2600 }) {
  const [index, setIndex] = useState(0);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    if (reduced) return undefined;
    const id = setInterval(() => setIndex((i) => (i + 1) % words.length), interval);
    return () => clearInterval(id);
  }, [reduced, interval, words.length]);

  return (
    <span className="rotating">
      <span className="visually-hidden">{words.join(', ')}</span>
      {/* key forces a remount so the CSS enter animation replays for each word */}
      <span key={index} className="rotating__word" aria-hidden="true">
        {words[index]}
      </span>
    </span>
  );
}
