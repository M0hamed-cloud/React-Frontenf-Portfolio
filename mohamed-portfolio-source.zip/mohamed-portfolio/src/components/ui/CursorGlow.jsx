import { useEffect, useRef } from 'react';
import { usePrefersReducedMotion } from '../../hooks/usePrefersReducedMotion';

/**
 * A soft accent-coloured spotlight that eases toward the pointer.
 * Skipped entirely on touch devices and for reduced-motion visitors.
 */
export default function CursorGlow() {
  const ref = useRef(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    if (reduced || window.matchMedia('(pointer: coarse)').matches) return undefined;

    const el = ref.current;
    let x = window.innerWidth * 0.6;
    let y = window.innerHeight * 0.3;
    let targetX = x;
    let targetY = y;
    let frame = 0;

    const tick = () => {
      x += (targetX - x) * 0.14;
      y += (targetY - y) * 0.14;
      el.style.transform = `translate3d(${x}px, ${y}px, 0)`;
      const settled = Math.abs(targetX - x) < 0.5 && Math.abs(targetY - y) < 0.5;
      frame = settled ? 0 : requestAnimationFrame(tick);
    };

    const onMove = (event) => {
      targetX = event.clientX;
      targetY = event.clientY;
      el.classList.add('is-active');
      if (!frame) frame = requestAnimationFrame(tick);
    };

    window.addEventListener('pointermove', onMove, { passive: true });
    return () => {
      window.removeEventListener('pointermove', onMove);
      cancelAnimationFrame(frame);
    };
  }, [reduced]);

  if (reduced) return null;
  return <div ref={ref} className="cursor-glow" aria-hidden="true" />;
}
