import { useInView } from '../../hooks/useInView';

/**
 * Fades + lifts its children into place the first time they scroll into view.
 * The animation itself lives in CSS (.reveal) so it is disabled automatically
 * for visitors who prefer reduced motion.
 *
 * @param {string} as       element/tag to render (defaults to div)
 * @param {number} delay    stagger delay in ms
 */
export default function Reveal({ as: Tag = 'div', delay = 0, className = '', children, ...rest }) {
  const [ref, inView] = useInView();

  return (
    <Tag
      ref={ref}
      className={`reveal${inView ? ' is-in' : ''} ${className}`.trim()}
      style={{ '--reveal-delay': `${delay}ms` }}
      {...rest}
    >
      {children}
    </Tag>
  );
}
