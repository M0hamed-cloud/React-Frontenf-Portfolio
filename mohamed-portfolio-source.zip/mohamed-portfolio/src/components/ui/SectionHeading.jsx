import Reveal from './Reveal';

/**
 * Shared section header: mono kicker ("02 ── Training"), serif title, optional lead.
 * `id` is used by the parent <section aria-labelledby>.
 */
export default function SectionHeading({ index, label, title, lead, id }) {
  return (
    <header className="section-heading">
      <Reveal>
        <p className="section-heading__kicker">
          <span className="section-heading__index">{index}</span>
          <span className="section-heading__rule" aria-hidden="true" />
          <span>{label}</span>
        </p>
      </Reveal>
      <Reveal delay={70}>
        <h2 id={id} className="section-heading__title">
          {title}
        </h2>
      </Reveal>
      {lead && (
        <Reveal delay={140}>
          <p className="section-heading__lead">{lead}</p>
        </Reveal>
      )}
    </header>
  );
}
