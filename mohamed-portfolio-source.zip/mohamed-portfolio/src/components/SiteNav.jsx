import { useEffect, useState } from 'react';
import { Container, Nav, Navbar } from 'react-bootstrap';
import { profile, sections } from '../data/profile';

// Home is reached via the brand; everything else gets a numbered link.
const links = sections.filter((s) => s.id !== 'home');

/**
 * Fixed top navigation (react-bootstrap Navbar, restyled in _layout.scss).
 * - Gains a blurred backdrop after the page scrolls.
 * - Highlights the section currently in view (`active`, from useScrollSpy).
 * - Collapses into a menu below the `md` breakpoint and closes after a link is chosen.
 */
export default function SiteNav({ active }) {
  const [expanded, setExpanded] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const close = () => setExpanded(false);

  return (
    <Navbar
      as="header"
      fixed="top"
      expand="md"
      expanded={expanded}
      onToggle={setExpanded}
      className={`site-nav${scrolled || expanded ? ' is-scrolled' : ''}`}
    >
      <Container>
        <Navbar.Brand href="#home" className="site-nav__brand" onClick={close} aria-label={`${profile.name} — home`}>
          <span className="monogram" aria-hidden="true">
            MA
          </span>
          <span className="site-nav__name">{profile.name}</span>
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="primary-nav" className="site-nav__toggle">
          <span className="burger" aria-hidden="true" />
          <span className="visually-hidden">Toggle navigation</span>
        </Navbar.Toggle>

        <Navbar.Collapse id="primary-nav">
          <Nav as="nav" aria-label="Primary" className="ms-auto align-items-md-center">
            {links.map((link, i) => (
              <Nav.Link
                key={link.id}
                href={`#${link.id}`}
                active={active === link.id}
                onClick={close}
                aria-current={active === link.id ? 'true' : undefined}
              >
                <span className="site-nav__num">{String(i + 1).padStart(2, '0')}</span>
                {link.label}
              </Nav.Link>
            ))}
            <a className="btn btn-sm btn-ghost site-nav__cta" href={profile.cvUrl} download>
              Résumé
            </a>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}
