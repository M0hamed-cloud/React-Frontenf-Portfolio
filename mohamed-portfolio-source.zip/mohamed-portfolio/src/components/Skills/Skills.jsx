import { useRef, useState } from 'react';
import { Container } from 'react-bootstrap';
import { skillGroups, ticker } from '../../data/profile';
import Reveal from '../ui/Reveal';
import SectionHeading from '../ui/SectionHeading';

/** Slow horizontal ticker of the core stack. Decorative, so hidden from assistive tech. */
function Ticker() {
  const loop = [...ticker, ...ticker];
  return (
    <div className="ticker" aria-hidden="true">
      <div className="ticker__track">
        {loop.map((name, i) => (
          // The second copy exists only to make the loop seamless; reduced-motion CSS hides it.
          <span key={`${name}-${i}`} className={`ticker__item${i >= ticker.length ? ' is-dup' : ''}`}>
            {name}
          </span>
        ))}
      </div>
    </div>
  );
}

/**
 * Skills explorer — an accessible tabs pattern:
 * arrow keys / Home / End move between categories, the panel updates on selection.
 */
export default function Skills() {
  const [activeId, setActiveId] = useState(skillGroups[0].id);
  const tabRefs = useRef({});
  const group = skillGroups.find((g) => g.id === activeId);

  const select = (id) => {
    setActiveId(id);
    tabRefs.current[id]?.focus();
  };

  const onKeyDown = (event) => {
    const index = skillGroups.findIndex((g) => g.id === activeId);
    const last = skillGroups.length - 1;
    const keyMap = {
      ArrowDown: (index + 1) % skillGroups.length,
      ArrowRight: (index + 1) % skillGroups.length,
      ArrowUp: (index - 1 + skillGroups.length) % skillGroups.length,
      ArrowLeft: (index - 1 + skillGroups.length) % skillGroups.length,
      Home: 0,
      End: last,
    };
    if (event.key in keyMap) {
      event.preventDefault();
      select(skillGroups[keyMap[event.key]].id);
    }
  };

  return (
    <section id="skills" className="section" aria-labelledby="skills-title">
      <Container>
        <SectionHeading
          id="skills-title"
          index="03"
          label="Technical skills"
          title={
            <>
              The toolkit, <em>organised by how I use it.</em>
            </>
          }
          lead="Pick a category. Core skills are where I build daily; foundations are where I’m actively growing."
        />

        <Reveal>
          <Ticker />
        </Reveal>

        <Reveal delay={80} className="skills">
          <div className="skills__tabs" role="tablist" aria-label="Skill categories" aria-orientation="vertical" onKeyDown={onKeyDown}>
            {skillGroups.map((g, i) => {
              const selected = g.id === activeId;
              return (
                <button
                  key={g.id}
                  ref={(node) => {
                    tabRefs.current[g.id] = node;
                  }}
                  type="button"
                  role="tab"
                  id={`tab-${g.id}`}
                  aria-selected={selected}
                  aria-controls="skills-panel"
                  tabIndex={selected ? 0 : -1}
                  className={`skills__tab${selected ? ' is-active' : ''}`}
                  onClick={() => setActiveId(g.id)}
                >
                  <span className="skills__tab-num">{String(i + 1).padStart(2, '0')}</span>
                  <span className="skills__tab-label">{g.label}</span>
                  <span className="skills__tab-count">{g.items.length}</span>
                </button>
              );
            })}
          </div>

          {/* key remounts the panel so list items replay their entrance animation */}
          <div key={group.id} id="skills-panel" role="tabpanel" aria-labelledby={`tab-${group.id}`} className="skills__panel" tabIndex={0}>
            <header className="skills__panel-head">
              <div>
                <h3>{group.label}</h3>
                <p>{group.blurb}</p>
              </div>
              <span className="level-badge">{group.level}</span>
            </header>

            <ul className="skill-list">
              {group.items.map((item, i) => (
                <li key={item.name} className="skill-list__item" style={{ '--i': i }}>
                  <span className="skill-list__name">{item.name}</span>
                  <span className="skill-list__note">{item.note}</span>
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}
