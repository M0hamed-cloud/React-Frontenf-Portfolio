import About from './components/About/About';
import Contact from './components/Contact/Contact';
import Footer from './components/Footer';
import Hero from './components/Hero/Hero';
import Projects from './components/Projects/Projects';
import SiteNav from './components/SiteNav';
import Skills from './components/Skills/Skills';
import Training from './components/Training/Training';
import CursorGlow from './components/ui/CursorGlow';
import ScrollProgress from './components/ui/ScrollProgress';
import { sections } from './data/profile';
import { useScrollSpy } from './hooks/useScrollSpy';

/**
 * Page shell. Sections are plain components rendered in order; content lives in data/profile.js.
 */
export default function App() {
  const active = useScrollSpy(sections.map((s) => s.id));

  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>

      <ScrollProgress />
      <CursorGlow />
      <SiteNav active={active} />

      <main id="main">
        <Hero />
        <About />
        <Training />
        <Skills />
        <Projects />
        <Contact />
      </main>

      <Footer />
    </>
  );
}
