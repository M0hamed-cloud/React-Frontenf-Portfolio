/**
 * Single source of truth for every piece of content on the site.
 *
 * All facts below come from Mohamed's CV (Mohamed_Ahmed_FrontEnd_CV.pdf).
 * To update the portfolio, edit this file — components only render what they find here.
 */

export const profile = {
  name: 'Mohamed Ahmed',
  firstName: 'Mohamed',
  role: 'Front-End Developer',
  location: 'Qalyubia, Egypt',
  email: 'mido2892006@gmail.com',
  phone: '+201063818055',
  phoneDisplay: '+20 106 381 8055',
  whatsapp: 'https://wa.me/201063818055',
  // Relative to the site root so it works under any `base` path.
  cvUrl: `${import.meta.env.BASE_URL}Mohamed_Ahmed_FrontEnd_CV.pdf`,

  /**
   * Optional profile links. Leave a value empty and the link is simply not rendered
   * (no dead buttons). Example: github: 'https://github.com/your-handle'
   */
  socials: {
    github: '',
    linkedin: '',
  },

  /** Words that cycle in the hero ("Currently sharpening …"). */
  focusWords: ['React', 'TypeScript', 'responsive layouts', 'clean code', 'component architecture'],
};

/** Order matters: it drives the nav and the scroll-spy. */
export const sections = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'training', label: 'Training' },
  { id: 'skills', label: 'Skills' },
  { id: 'projects', label: 'Projects' },
  { id: 'contact', label: 'Contact' },
];

/* ------------------------------------------------------------------ */
/* About                                                               */
/* ------------------------------------------------------------------ */

export const education = {
  degree: 'Bachelor of Computer Science',
  institution: 'Thebes Academy',
  place: 'Maadi, Cairo, Egypt',
  currentYear: 3,
  totalYears: 4,
  expectedGraduation: 'June 2028',
};

export const principles = [
  {
    title: 'Component thinking',
    text: 'I design UIs as small, reusable pieces with clean state management, so features stay easy to change, test and reason about.',
  },
  {
    title: 'Detail-first interfaces',
    text: 'UI/UX principles, responsive layouts and accessibility are part of the first draft, not a polish pass at the end.',
  },
  {
    title: 'Full-stack aware',
    text: 'Practical exposure to Node.js, Express and Docker basics means I can collaborate with backend teammates without friction.',
  },
];

/* ------------------------------------------------------------------ */
/* Professional training                                               */
/* ------------------------------------------------------------------ */

export const training = {
  role: 'Front-End Web Development Trainee',
  organisation: 'Digital Egypt Pioneers Initiative (DEPI)',
  parent: 'Ministry of Communications and Information Technology (MCIT)',
  start: '2026-07-01',
  startLabel: 'July 2026',
  endLabel: 'Present',
  tracks: [
    {
      title: 'Modern web development',
      text: 'Building responsive, accessible and high-performance client-side applications with React, TypeScript and modern state management.',
      tags: ['React', 'TypeScript', 'State management'],
    },
    {
      title: 'UI/UX & component architecture',
      text: 'Intensive training covering modern web development, UI/UX principles and how to structure interfaces as composable components.',
      tags: ['UI/UX', 'Components', 'Accessibility'],
    },
    {
      title: 'Engineering discipline',
      text: 'Applying software design patterns, clean-code best practices, unit-testing fundamentals and functional documentation.',
      tags: ['Design patterns', 'Clean code', 'Unit testing', 'Docs'],
    },
    {
      title: 'Full-stack collaboration',
      text: 'Foundational backend knowledge (Node.js & Express) and containerization basics (Docker) for seamless collaboration across the stack.',
      tags: ['Node.js', 'Express', 'Docker'],
    },
  ],
};

/* ------------------------------------------------------------------ */
/* Skills                                                              */
/* ------------------------------------------------------------------ */

export const skillGroups = [
  {
    id: 'frontend',
    label: 'Front-End',
    level: 'Core',
    blurb: 'Where I spend most of my time: turning designs into fast, responsive, accessible interfaces.',
    items: [
      { name: 'React.js', note: 'Component-based UIs, reusable building blocks' },
      { name: 'JavaScript (ES6+)', note: 'Modern syntax, modules, async patterns' },
      { name: 'TypeScript', note: 'Typed props and safer refactors' },
      { name: 'HTML5', note: 'Semantic, accessible markup' },
      { name: 'CSS3', note: 'Layout, custom properties, animation' },
      { name: 'Bootstrap', note: 'Grid and utilities, customised via Sass' },
      { name: 'Responsive Web Design', note: 'Mobile-first, cross-browser layouts' },
      { name: 'UI/UX Design Principles', note: 'Hierarchy, spacing, usability' },
    ],
  },
  {
    id: 'backend',
    label: 'Backend & Tooling',
    level: 'Foundations',
    blurb: 'Enough of the server side to collaborate well and ship a full feature end to end.',
    items: [
      { name: 'Node.js', note: 'Runtime fundamentals' },
      { name: 'Express', note: 'Routing and REST basics' },
      { name: 'Docker', note: 'Containerization basics' },
      { name: 'Unit Testing', note: 'Testing fundamentals' },
    ],
  },
  {
    id: 'tools',
    label: 'Tools & Platforms',
    level: 'Daily drivers',
    blurb: 'The everyday workflow: version control, an editor I know well, and AI-assisted iteration.',
    items: [
      { name: 'Git', note: 'Branching, commits, collaborative workflow' },
      { name: 'GitHub', note: 'Repositories, organisation, pull requests' },
      { name: 'VS Code', note: 'Editor, debugging, extensions' },
      { name: 'Prompt Engineering', note: 'Getting reliable results from AI tools' },
    ],
  },
  {
    id: 'craft',
    label: 'Engineering Craft',
    level: 'Practice',
    blurb: 'Habits that keep a codebase pleasant to work in six months from now.',
    items: [
      { name: 'Component-Based Architecture', note: 'Composition over duplication' },
      { name: 'Clean Code Practices', note: 'Readable, consistent, maintainable' },
      { name: 'Functional Documentation', note: 'Docs that explain what and why' },
    ],
  },
];

/** Names shown in the slow-moving ticker above the skill explorer. */
export const ticker = [
  'React',
  'TypeScript',
  'JavaScript ES6+',
  'HTML5',
  'CSS3',
  'Bootstrap',
  'Node.js',
  'Express',
  'Docker',
  'Git',
  'GitHub',
  'Clean Code',
];

/* ------------------------------------------------------------------ */
/* Projects                                                            */
/* ------------------------------------------------------------------ */

/**
 * `links.repo` / `links.demo` are optional. When empty the button is not rendered.
 * Every card always gets a "Discuss this project" email link.
 */
export const projects = [
  {
    id: 'react-web-apps',
    index: '01',
    kind: 'Front-end · React',
    title: 'React & Web Applications Portfolio',
    summary:
      'A body of React and web work built around reusable components, clean state management and interfaces that hold up on every screen size.',
    highlights: [
      {
        label: 'Interfaces',
        text: 'Responsive, user-friendly web interfaces emphasizing reusability and clean state management.',
      },
      {
        label: 'Styling',
        text: 'CSS3 and Bootstrap used to guarantee seamless cross-browser and mobile compatibility.',
      },
      {
        label: 'Workflow',
        text: 'Git and GitHub for version control, repository organization and collaborative workflows.',
      },
    ],
    tags: ['React', 'JavaScript ES6+', 'CSS3', 'Bootstrap', 'Git', 'GitHub'],
    links: { repo: '', demo: '' },
  },
  {
    id: 'this-portfolio',
    index: '02',
    kind: 'Front-end · Design engineering',
    title: 'This Portfolio',
    summary:
      'The site you are on: a component-based React app with Bootstrap customised through Sass tokens, so it uses a proven grid without looking like stock Bootstrap.',
    highlights: [
      {
        label: 'Architecture',
        text: 'Small, documented components with a single content file driving every section.',
      },
      {
        label: 'Interaction',
        text: 'Scroll-spy navigation, reveal-on-scroll, a keyboard-accessible skill explorer, all respecting reduced-motion settings.',
      },
      {
        label: 'Responsive',
        text: 'Designed mobile-first and verified from phone widths up to wide desktop screens.',
      },
    ],
    tags: ['React', 'Bootstrap', 'Sass', 'Vite', 'Semantic HTML', 'Accessibility'],
    swatches: [
      { name: 'Ink', value: '#0a0c0f' },
      { name: 'Surface', value: '#12171d' },
      { name: 'Paper', value: '#e9ece5' },
      { name: 'Signal', value: '#cdf545' },
    ],
    links: { repo: '', demo: '' },
  },
];
